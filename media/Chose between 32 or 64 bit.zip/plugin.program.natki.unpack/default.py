# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import zipfile
import shutil

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

def unpack_architecture(arch):
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(0, "בחר תיקייה עם קבצי ה-ZIP", "files", "", False, False, "")
    if not folder:
        return

    for fname in os.listdir(folder):
        if not fname.endswith(".zip"):
            continue
        fpath = os.path.join(folder, fname)
        try:
            with zipfile.ZipFile(fpath, 'r') as z:
                namelist = z.namelist()
                valid = False
                for n in namelist:
                    if "addon.xml" in n:
                        data = z.read(n).decode("utf-8", "ignore")
                        if arch in data:
                            valid = True
                            break
                if not valid:
                    continue

                target_dir = xbmc.translatePath("special://home/addons")
                z.extractall(target_dir)
                dialog.notification("NATKI Installer", f"הותקן: {fname}", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            dialog.notification("NATKI Installer", f"שגיאה: {fname}", xbmcgui.NOTIFICATION_ERROR, 4000)

    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("Container.Refresh")

def router(param):
    if param == "32":
        unpack_architecture("android-armv7")
    elif param == "64":
        unpack_architecture("android-aarch64")
    else:
        dialog = xbmcgui.Dialog()
        choice = dialog.select("בחר ארכיטקטורה", ["32 ביט (armv7)", "64 ביט (aarch64)"])
        if choice == 0:
            unpack_architecture("android-armv7")
        elif choice == 1:
            unpack_architecture("android-aarch64")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 2:
        router(sys.argv[2])
    else:
        router("")
