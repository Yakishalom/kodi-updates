import os

if os.name == 'nt':
    from windows_handler import run_windows_installer
    run_windows_installer()
else:
    from android_handler import copy_inner_folders_from_github_zip
    copy_inner_folders_from_github_zip()
