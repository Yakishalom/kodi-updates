import xbmcgui
import xbmc
import threading

class NextEpisodeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.url = kwargs.get("url", "")
        self.title = kwargs.get("title", "פרק חדש")
        self.thumb = kwargs.get("thumb", "")
        self.countdown = kwargs.get("countdown", 10)
        self._cancel = False
        self._confirmed = False  # 🟡 חדש: אם המשתמש אישר ניגון

    def onInit(self):
        self.setProperty("title", self.title)
        self.setProperty("thumb", self.thumb)
        self.update_timer_async()
        self.setFocusId(10)  # ⬅️ פוקוס על כפתור "נגן"


    def onClick(self, controlId):
        if controlId == 10:  # נגן עכשיו
            self._confirmed = True  # 🟢 המשתמש לחץ נגן
            self._cancel = True
            xbmc.Player().stop()
            self.close()
            # xbmc.sleep(500)
            # xbmc.executebuiltin(f'PlayMedia("{self.url}")')
        elif controlId == 11:  # ביטול
            self._cancel = True
            self.close()

    def update_timer_async(self):
        def countdown():
            seconds = self.countdown
            while seconds > 0 and not self._cancel:
                self.setProperty("timer", str(seconds))
                xbmc.sleep(1000)
                seconds -= 1
            if not self._cancel and self._confirmed:
                xbmc.Player().stop()
                # xbmc.sleep(500)
                # xbmc.executebuiltin(f'PlayMedia("{self.url}")')
            self.close()  # תמיד סוגר – בלי לנגן אם לא אושר

        threading.Thread(target=countdown).start()
